import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AppModif {
    public static void main(String[] args) {
        List<Profesor> profesors = new ArrayList<>();
        List<Salon> salons = new ArrayList<>();
        List<Materia> materias = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        
        int opcion;
        
        do {
            System.out.println("\n--- Menu ---");
            System.out.println("1) Agregar un profesor");
            System.out.println("2) Agregar un salón");
            System.out.println("3) Agregar una materia");
            System.out.println("4) Salir del programa");
            System.out.println("5) Mostrar materias registradas");
            System.out.println("Ingrese una opción:");
            
            opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la nueva línea

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese el nombre del profesor:");
                    String nombreProfesor = scanner.nextLine();
                    System.out.println("Ingrese la clave del profesor:");
                    String claveProfesor = scanner.nextLine();
                    System.out.println("Ingrese la edad del profesor:");
                    int edadProfesor = scanner.nextInt();
                    scanner.nextLine(); // Consumir la nueva línea
                    
                    profesors.add(new Profesor(nombreProfesor, edadProfesor, claveProfesor));
                    System.out.println("Profesor agregado con éxito.");
                    break;
                
                case 2:
                    System.out.println("Ingrese el nombre del salón:");
                    String nombreSalon = scanner.nextLine();
                    System.out.println("Ingrese el edificio del salón:");
                    String edificioSalon = scanner.nextLine();
                    
                    salons.add(new Salon(nombreSalon, edificioSalon));
                    System.out.println("Salón agregado con éxito.");
                    break;

                case 3:
                    if (profesors.isEmpty() || salons.isEmpty()) {
                        System.out.println("Error: No hay profesores o salones registrados. Agregue al menos uno de cada uno antes de registrar una materia.");
                    } else {
                        System.out.println("Ingrese el nombre de la materia:");
                        String nombreMateria = scanner.nextLine();

    
                        System.out.println("Seleccione un profesor:");
                        for (int i = 0; i < profesors.size(); i++) {
                            System.out.println(i + ") " + profesors.get(i).getNombre());
                        }
                        int profesorIndex = scanner.nextInt();
                        scanner.nextLine(); 

                        System.out.println("Seleccione un salón:");
                        for (int i = 0; i < salons.size(); i++) {
                            System.out.println(i + ") " + salons.get(i).getNombre());
                        }
                        int salonIndex = scanner.nextInt();
                        scanner.nextLine();

                        Materia nuevaMateria = new Materia(nombreMateria, profesors.get(profesorIndex), salons.get(salonIndex));
                        materias.add(nuevaMateria);
                        System.out.println("Materia agregada con éxito.");
                    }
                    break;

                case 4:
                    System.out.println("Saliendo del programa...");
                    break;

                case 5:
                    if (materias.isEmpty()) {
                        System.out.println("No hay materias registradas.");
                    } else {
                        System.out.println("Materias Registradas:");
                        for (Materia materia : materias) {
                            System.out.println("Nombre: " + materia.getNombre());
                            System.out.println("Profesor: " + materia.getProfesor().getNombre() + ", Edad: " + materia.getProfesor().getEdad() + ", Clave: " + materia.getProfesor().getClave());
                            System.out.println("Salón: " + materia.getSalon().getNombre() + ", Edificio: " + materia.getSalon().getEdificio());
                            System.out.println("");
                        }
                    }
                    break;

                default:
                    System.out.println(" Intente de nuevo.");
                    break;
            }
        } while (opcion != 4);

        scanner.close();
    }
}
